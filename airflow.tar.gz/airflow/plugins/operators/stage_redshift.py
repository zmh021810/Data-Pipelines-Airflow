from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.contrib.hooks.aws_hook import AwsHook

class StageToRedshiftOperator(BaseOperator):
    
    '''
    this class is used to build the Stage
    for the init function, we have 8 additional parameters:
    redshift_id: this is the name of the redshift server, we need this one to build the connection to redshift
    aws_credentials_id: this saves the IAM user information
    table_name: the stage table name
    s3_key_name: the prefix path of the data in S3
    s3_bucket_name: S3 bucket name
    json_path: jason file path
    file_type: file format
    ignore_headers: ignore the headers when read csv  
    '''
    
    ui_color = '#358140'

    @apply_defaults
    def __init__(self,
                 # Define your operators params (with defaults) here
                 # Example:
                 # redshift_conn_id=your-connection-name
                 redshift_id="", aws_credentials_id="", table_name="",
                 s3_key_name="", s3_bucket_name="", json_path="",
                 file_type="json", ignore_headers=1, *args, **kwargs):

        super(StageToRedshiftOperator, self).__init__(*args, **kwargs)
        # Map params here
        # Example:
        # self.conn_id = conn_id
        self.aws_credentials_id = aws_credentials_id
        self.redshift_id = redshift_id
        self.table = table_name
        self.s3_bucket = s3_bucket_name
        self.s3_key = s3_key_name
        self.json_path = json_path
        self.file_type = file_type
        self.ignore_headers = ignore_headers

    def execute(self, context):
        self.log.info('StageToRedshiftOperator not implemented yet')
        airflow_hook = AwsHook(self.aws_credentials_id)
        aws_cre = airflow_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_id)
        
        print("remove the data in the server if there are any")
        redshift.run(f"DELETE FROM {self.table}")

        print("now start to copy the data from S3 to the AWS redshift server")
        rendered_key = self.s3_key.format(**context)
        
        print("generate the data path")
        s3_path = "s3://" + self.s3_bucket + rendered_key

        print("check the file data type, jason or csv")
        
        if self.file_type == "csv":
            sql_code = f"COPY {self.table} \
                         FROM '{s3_path}' \
                         ACCESS_KEY_ID '{aws_cre.access_key}'\
                         SECRET_ACCESS_KEY '{aws_cre.secret_key}'\
                         CSV 'auto'\
                         IGNOREHEADER {self.ignore_headers}\
                         DELIMITER ',';"

        elif self.file_type == "json":
            sql_code = f"COPY {self.table} \
                         FROM '{s3_path}' \
                         ACCESS_KEY_ID '{aws_cre.access_key}'\
                         SECRET_ACCESS_KEY '{aws_cre.secret_key}'\
                         TIMEFORMAT as 'epochmillisecs'\
                         JSON '{self.json_path}' COMPUPDATE OFF;"
            
        redshift.run(sql_code)
        
        self.log.info('The process for StageToRedshiftOperator is finished')
        
            





