from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):
    
    
    """
        generate dimension tables from the staging tables to the AWS redshift server.
        there are four variables: 
        redshift_id = redshift name created in the server set up
        sql_code = sql code from the sql_queries.py
        table = dimension table name 
        append is fixed as False, below is the details:
        False = replace data in dimension table, 
        True = add data to the dimension table
    """
    

    ui_color = '#80BD9E'

    @apply_defaults
    def __init__(self,
                 # Define your operators params (with defaults) here
                 # Example:
                 # conn_id = your-connection-name
                 redshift_id="", table_name="", sql_code="", append=False, *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        # Map params here
        # Example:
        # self.conn_id = conn_id
        self.redshift_id = redshift_id
        self.table = table_name
        self.sql_code = sql_code
        self.append = append

    def execute(self, context):
        self.log.info('LoadDimensionOperator not implemented yet')
        self.log.info('start to hook the redshift postgres server')
        redshift = PostgresHook(postgres_conn_id=self.redshift_id)

        self.log.info('check if there are already data in the table')
        if not self.append:
            redshift.run(f"TRUNCATE TABLE {self.table}")
        redshift.run(f"INSERT INTO {self.table} {self.sql_code}")
        self.log.info(f"{self.task_id} is finished")
