from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):
    
    '''
    this class is used to build the data quality check
    for the init function, we have two additional parameters:
    redshift_id: this is the name of the redshift server, we need this one to build the connection to redshift
    table: it is a list which saves the tables which we need to check
    
    '''

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 # Define your operators params (with defaults) here
                 # Example:
                 # conn_id = your-connection-name
                 redshift_id="", tables=[], *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        # Map params here
        # Example:
        # self.conn_id = conn_id
        self.tables = tables
        self.redshift_id = redshift_id

    def execute(self, context):
        self.log.info('DataQualityOperator not implemented yet')
        self.log.info('Start to hook the redshift postgres sql server')
        redshift_hook = PostgresHook(self.redshift_id)

        self.log.info('For loop to check the tables one by one')
        for each in self.tables:
            self.log.info(f"{each} Data Quality check starts")
            sql_code=f"SELECT COUNT(*) FROM {each};"
            records = redshift_hook.get_records(sql_code)
            if len(records[0]) < 1 or len(records) < 1:
                raise ValueError(f"Error happens, There is no data in Table {each}, pls check the data load and DAG set up")
            if records[0][0] < 1:
                raise ValueError(f"Error happens, There is no data in Table {each}, pls check the data load and DAG set up")
            self.log.info(f"Table {each} Data Quality check does not find any errors, this table has {records[0][0]} rows")