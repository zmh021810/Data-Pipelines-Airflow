from datetime import datetime, timedelta
import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators import (StageToRedshiftOperator, LoadFactOperator,
                                LoadDimensionOperator, DataQualityOperator)
from helpers import SqlQueries

# AWS_KEY = os.environ.get('AWS_KEY')
# AWS_SECRET = os.environ.get('AWS_SECRET')

default_args = {
    'owner': 'udacity',
    'start_date': datetime(2019, 1, 12),
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': False,
    'depends_on_past': False,
    'catchup': False
}

dag = DAG('udac_example_dag',
          default_args=default_args,
          description='Load and transform data in Redshift with Airflow',
          schedule_interval='0 * * * *'
        )

start_operator = DummyOperator(task_id='Begin_execution',  dag=dag)

stage_events_to_redshift = StageToRedshiftOperator(
    task_id='Stage_events',
    dag=dag,
    redshift_id="redshift",
    aws_credentials_id="aws_credentials",
    table_name="staging_events",
    s3_key_name="log_data",
    s3_bucket_name="udacity-dend",
    json_path="s3://udacity-dend/log_json_path.json"
)

stage_songs_to_redshift = StageToRedshiftOperator(
    task_id='Stage_songs',
    dag=dag,
    redshift_id="redshift",
    aws_credentials_id="aws_credentials",
    table_name="staging_songs",
    s3_key_name="song_data/A/A/A",
    s3_bucket_name="udacity-dend",
    json_path="auto"
)

load_songplays_table = LoadFactOperator(
    task_id='Load_songplays_fact_table',
    dag=dag,
    redshift_id="redshift",
    table_name='songplays',
    sql_code=SqlQueries.songplay_table_insert
)

load_user_dimension_table = LoadDimensionOperator(
    task_id='Load_user_dim_table',
    dag=dag,
    redshift_id="redshift",
    table_name='users',
    sql_code=SqlQueries.user_table_insert
)

load_song_dimension_table = LoadDimensionOperator(
    task_id='Load_song_dim_table',
    dag=dag,
    redshift_id="redshift",
    table_name='songs',
    sql_code=SqlQueries.song_table_insert
)

load_artist_dimension_table = LoadDimensionOperator(
    task_id='Load_artist_dim_table',
    dag=dag,
    redshift_id="redshift",
    table_name='artists',
    sql_code=SqlQueries.artist_table_insert
)

load_time_dimension_table = LoadDimensionOperator(
    task_id='Load_time_dim_table',
    dag=dag,
    redshift_id="redshift",
    table_name='time',
    sql_code=SqlQueries.time_table_insert
)

run_quality_checks = DataQualityOperator(
    task_id='Run_data_quality_checks',
    dag=dag,
    redshift_id="redshift",
    tables=['songs', 'users', 'time', 'songplays', 'artists']
)


end_operator = DummyOperator(task_id='Stop_execution',  dag=dag)


print("start to buid the DAG")
print("create two start operators")
start_operator >> stage_songs_to_redshift
start_operator >> stage_events_to_redshift


print("create fact table")
stage_songs_to_redshift >> load_songplays_table
stage_events_to_redshift >> load_songplays_table


print("create dimension tables")
load_songplays_table >> load_user_dimension_table
load_songplays_table >> load_song_dimension_table
load_songplays_table >> load_artist_dimension_table
load_songplays_table >> load_time_dimension_table


print("run quality checks")
load_user_dimension_table >> run_quality_checks
load_song_dimension_table >> run_quality_checks
load_artist_dimension_table >> run_quality_checks
load_time_dimension_table >> run_quality_checks


print("DAG end")
run_quality_checks >> end_operator
